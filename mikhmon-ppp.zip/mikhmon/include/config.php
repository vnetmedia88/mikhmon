<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');










$data['10.10.1.2'] = array ('1'=>'10.10.1.2!10.10.1.2','10.10.1.2@|@api','10.10.1.2#|#maGb','10.10.1.2%10.10.1.2','10.10.1.2^10.10.1.2','10.10.1.2&Rp','10.10.1.2*10','10.10.1.2(1','10.10.1.2)','10.10.1.2=10','10.10.1.2@!@enable');